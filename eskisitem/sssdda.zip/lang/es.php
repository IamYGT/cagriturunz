<?php  

define("MENU_ANASAYFA","inicio"); 
define("MENU_KURUMSAL","Sobre Nosotros");
define("MENU_TURLAR","Tours");       
define("MENU_BALONLAR","Globos");       
define("MENU_AKTIVITELER","Actividades"); 
define("MENU_TRANSFER","Transfer");
define("MENU_ILETISIM","Contact"); 
define("MENU_REZERVASYON","Reservacion");

define("LINK_TURLAR","tours");
define("LINK_BALONLAR","globos");
define("LINK_AKTIVITELER","actividades");
define("LINK_TRANSFER","transfer");
define("LINK_ILETISIM","contact");
define("LINK_REZERVASYON","reservacion");

/*Aktivite İçerik Açıklama Başlangıç */

define("AKTIVITE_BASLIK","Actividades");
define("AKTIVITE_ACIKLAMA","Actividades");

/*Aktivite İçerik Açıklama Bitiş */

define("TEXT_1","Tours"); 
define("TEXT_2"," PAQUETES PRIVADOS ");
define("TEXT_3"," ACTİVİDADES ");
define("TEXT_4"," Hemos prepado estos probramas para que nuestros clıentes aprevochen. "); 
define("TEXT_5","Paseo en globo aerostático"); 
define("TEXT_6"," SOLİCİTİD ESPECİAL ");
define("TEXT_7"," Pide Su Solicitud "); 
define("TEXT_8"," Registre su dirección de correo electrónico para estar informado sobre nosotros.");
define("TEXT_9"," Suscríbase a nuestro boletín "); 
define("TEXT_10"," Suscríbete "); 
define("TEXT_11"," CONTÁCTENOS "); 
define("TEXT_12"," CONEXIONES EXTRA "); 
define("TEXT_13"," NUESTROS SERVİCİOS "); 
define("TEXT_14"," Reserva Ahora.");

/*Rezervasyon Kısmı Başlangıç*/  

define("TEXT_15"," Explicacion ");
define("TEXT_16"," Precio "); 
define("TEXT_17"," Paquete ");
define("TEXT_18"," Numero De Grupo "); 
define("TEXT_19"," Precio ");  
define("TEXT_20"," Reservacion ");
define("TEXT_21"," Nombre Y Apellido ");
define("TEXT_22"," Correo Electrico ");
define("TEXT_23"," Telefono "); 
define("TEXT_24"," Nombre Del Hotel ");
define("TEXT_58"," Fecha ");
define("TEXT_25"," Su Mensaje ");
define("TEXT_26"," Elije El Numero ");
define("TEXT_27"," No Han Elegido Persona "); 
define("TEXT_28"," Cuanto Quiere Pagar ");
define("TEXT_29"," Precio Total "); 
define("TEXT_30","%25"); 
define("TEXT_31","%50");
define("TEXT_32"," İnformacion De Pago "); 
define("TEXT_33"," Precio Del Paquete "); 
define("TEXT_34","25 % De Pago ");
define("TEXT_35","50 % De Pago "); 
define("TEXT_36"," El Resto "); 
define("TEXT_37","Total");
define("TEXT_38"," Elije El Modelo De Pago "); 
define("TEXT_39"," Tarjeta De Credito "); 
define("TEXT_40"," Transferencia "); 
define("TEXT_59"," Numero De Tarjeta De Credito "); 
define("TEXT_60"," Nombre Y Apellido "); 
define("TEXT_61"," MES- ANO ");
define("TEXT_62","CVC");
define("TEXT_41"," Entre Elnumero De Securidad ");
define("TEXT_42"," Cree Su Reservacion ");
/*Rezervasyon Kısmı Bitiş*/ 

/*İletişim Kısmı Başlangıç*/ 

define("TEXT_43"," Contactenos ");
define("TEXT_44"," Nombre Y Apellido ");
define("TEXT_45"," Correo Electrónıco");
define("TEXT_46"," Numero De Telefono ");
define("TEXT_47"," Su Mensaje "); 
define("TEXT_48"," Contactenos ");
define("TEXT_49","7/24 Estamos Aqui Para Ayudarles ");
define("TEXT_50"," Direccion "); 
define("TEXT_51"," Correo Electronico "); 
define("TEXT_52","Telefono");
define("TEXT_74","Telefono Mobil");
define("TEXT_75","Para español y francés");

/*İletişim Kısmı Bitiş*/  

define("TEXT_53"," Formulario de solicitud especial "); 
define("TEXT_54"," Su solicitud recibido."); 
define("TEXT_55"," Error de entrega."); 
define("TEXT_56"," Dejaste espacio libre, vuelve a intentarlo."); 
define("TEXT_57"," El filtro de seguridad es incorrecto. Por favor intente nuevamente."); 
define("TEXT_63"," Nueva Reserva "); 
define("TEXT_64"," Numero De Reserva ");
define("TEXT_65"," Numero De Personas ");
define("TEXT_66"," Forma De Pago "); 
define("TEXT_67"," Forma De Pago "); 
define("TEXT_68"," Información de solicitud de reserva "); 
define("TEXT_69"," Cuanto Pagado "); 
define("TEXT_70"," Precie Del Paquete ");
define("TEXT_71"," Pago Total ");
define("TEXT_72"," El Resto Del Pago ");
define("TEXT_73"," Lo Que Has Hecho "); 
define("TEXT_75","He leído y acepto los términos");

define("TEXT_76","Airports");
define("TEXT_77","Transfer Type"); 
define("TEXT_78","Whatsapp"); 
define("TEXT_79","One Direction"); 
define("TEXT_80","Double Direction"); 
define("TEXT_81","Flight Code"); 
define("TEXT_82","Number of People"); 
define("TEXT_83","Arrival Information"); 
define("TEXT_84","Airport"); 
define("TEXT_85","Return Information"); 
define("TEXT_86","Payment information"); 
define("TEXT_87","One Way Total Price"); 
define("TEXT_88","Two Way Total Price"); 
define("TEXT_89","Total Price");  

define("DETAY"," Detalle ");   
define("DAHA_FAZLA"," Mas ");   
define("DAHA_FAZLA_OKU", " Mas "); 

define("ILETISIM_ADRES"," Habla a ");
define("ILETISIM_TELEFON"," Telefono ");
define("ILETISIM_EPOSTA"," Correo Electrónıco ");
define("ILETISIM_FAKS"," Fax ");
define("ILETISIM_HARITA"," Mapa "); 

define("SUBMIT"," Enviar ");
define("CANCEL"," Cancelar ");
?>